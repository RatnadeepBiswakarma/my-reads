import React, { Component } from "react";
// import BooksApp from './App';
import {Link} from 'react-router-dom';
// import BookInfo from './BookInfo';
// import { Route } from 'react-router-dom';

class Reading extends Component {
  books = this.props.books;

  render() {
    return (
      <div>
        {/* <Route path='/book-details' render={() => {
        return <BookInfo books={this.books}/>
        }}/> */}
        
        <div className="bookshelf">
          <h2 className="bookshelf-title">Currently Reading</h2>
          <div className="bookshelf-books">
            <ol className="books-grid">
              {this.books.map(book => {
                if (book.shelf === "currentlyReading") {
                  return (
                    <li key={book.id}>
                      <div className="book">
                        <div className="book-top">
                          <div
                            className="book-cover"
                            style={{
                              width: 128,
                              height: 193,
                              backgroundImage: `url(${
                                book.imageLinks.smallThumbnail
                              })`
                            }}
                          />
                          <div className="book-shelf-changer">
                            <select
                              defaultValue={book.shelf}
                              onChange={event =>
                                this.props.handleSelection(event, book)
                              }
                            >
                              <option value="move" disabled>
                                Move to...
                              </option>
                              <option value="currentlyReading ">
                                Currently Reading 🗸
                              </option>
                              <option value="wantToRead">Want to Read</option>
                              <option value="read">Read</option>
                              <option value="none">None</option>
                            </select>
                          </div>
                        </div>
                        <div className="book-title">{book.title}</div>
                        <div className="book-authors"><strong>V: </strong>{book.contentVersion}</div>
                        <div className="book-authors">{book.authors}</div>
                        <div className='book-authors'>Pages: {book.pageCount}</div>
                        <div className='book-authors'>Published by: {book.publisher} on {book.publishedDate}</div>
                      </div>
                    </li>
                  );
                }
              })}
            </ol>
          </div>
        </div>
      </div>
      
    );
  }
}

export default Reading;
